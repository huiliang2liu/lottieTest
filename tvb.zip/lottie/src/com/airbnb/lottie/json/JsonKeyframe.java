package com.airbnb.lottie.json;

public class JsonKeyframe {
}
