package com.zkk.lottietest;

import java.lang.Thread.UncaughtExceptionHandler;

import android.app.Application;
import android.os.Process;

/**
 * lottie com.zkk.lottietest 2018 2018-2-6 下午5:28:35 instructions：
 * author:liuhuiliang email:825378291@qq.com
 **/

public class MyApplication extends Application implements
		UncaughtExceptionHandler {
	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		Thread.setDefaultUncaughtExceptionHandler(this);
	}

	@Override
	public void uncaughtException(Thread thread, Throwable ex) {
		// TODO Auto-generated method stub
		ex.printStackTrace();
		Process.killProcess(Process.myPid());
		System.exit(0);
	}
}
