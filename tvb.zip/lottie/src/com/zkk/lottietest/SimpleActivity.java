package com.zkk.lottietest;

import android.app.Activity;
import android.os.Bundle;

import com.airbnb.lottie.LottieAnimationView;

/**
 * @author  zkk
 * 简书:    http://www.jianshu.com/u/61f41588151d
 * github: https://github.com/panacena
 */
public class SimpleActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // activity_simple.xml中 lottie_fileName="data.json"
        // 所以只需要在 app/src/main/assets 中添加AE 生成的 json文件，重命名为data.json就可以显示动画
        try {
        	LottieAnimationView view=new LottieAnimationView(this);
        	setContentView(view);
        	view.setAnimation("LottieLogo1.json");
        	view.loop(true);
        	view.playAnimation();
 		} catch (Exception e) {
			// TODO: handle exception
 			e.printStackTrace();
		}
    }
}
